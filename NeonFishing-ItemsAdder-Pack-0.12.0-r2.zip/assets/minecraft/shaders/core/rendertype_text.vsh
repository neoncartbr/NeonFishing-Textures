#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_42cd65a2(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_6d0039c3() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_8847d69e(inout vec4 vertex) {
    f_42cd65a2(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_6d0039c3();
    }
    finalize();
}



void f_5ccf14dc() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_17e66dda() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_3a4b8050(inout vec4 vertex) {
    f_42cd65a2(vertex);
    f_5ccf14dc();
    finalize();
}

void f_a7d16c53(inout vec4 vertex) {
    f_42cd65a2(vertex);
    f_6d0039c3();
    f_17e66dda();
    finalize();
}

void f_4e078c27(inout vec4 vertex) {
    f_42cd65a2(vertex);
    f_17e66dda();
    f_5ccf14dc();
    finalize();
}

void f_abb92772(inout vec4 vertex) {
    f_6d0039c3();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_42cd65a2(vertex);
    finalize();
}

void f_e05db66e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_5ccf14dc();
    f_42cd65a2(vertex);
    finalize();
}

void f_feb70788(inout vec4 vertex, float speed) {
    f_42cd65a2(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_0d83e084(inout vec4 vertex) {
    f_42cd65a2(vertex);
    f_6d0039c3();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_8847d69e(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_6d0039c3();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_42cd65a2(vertex);
            f_6d0039c3();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_a7d16c53(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_a7d16c53(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_abb92772(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_abb92772(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_feb70788(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_0d83e084(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_3a4b8050(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_a7d16c53(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_4e078c27(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_abb92772(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_e05db66e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_feb70788(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_3a4b8050(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_a7d16c53(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_4e078c27(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_abb92772(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_e05db66e(vertex);
        return;
    }
    

    
    f_42cd65a2(vertex);
    f_6d0039c3();
    finalize();
}